from django.urls import path, include
from rest_framework.routers import DefaultRouter

# Les vues seront ajoutées ultérieurement
urlpatterns = [
    # Les endpoints seront ajoutés dans l'étape 006
]
