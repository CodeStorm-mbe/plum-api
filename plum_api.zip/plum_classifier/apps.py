from django.apps import AppConfig


class PlumClassifierConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'plum_classifier'
